package org.cap.boot;

import java.util.List;

import org.cap.config.JavaConfig;
import org.cap.pojo.Book;
import org.cap.service.BookService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
		
		BookService bookService=(BookService)context.getBean("bookService");
		
	bookService.createBookTable();
		
	Book book=new Book(1, "java Complete Ref",1500, "Robert");
		Book book1=new Book(2, "Oracle Complete Ref",1200, "Jackson");
		Book book2=new Book(11, "SCJP",700, "Kathey Seira");
		
		Book book3=new Book(145, "Head First JAVA",1508, "Kathey Seira");
		Book book4=new Book(56, "Head First Servlet/JSP",1111, "Kathey Seira");
		
		bookService.insertBook(book);
		bookService.insertBook(book1);
		bookService.insertBook(book2);
		bookService.insertBook(book3);
		bookService.insertBook(book4);
		
		
		//bookService.deleteBook(56);
		
		/*int count=bookService.countAllRows();
		System.out.println("No of Rows:" + count);*/
		
		/*Book book=bookService.findBook(145);
		System.out.println(book);*/
		
		List<Book> books= bookService.getAllbooks();
		
		for(Book bookd:books)
			System.out.println(bookd);
	}

}
