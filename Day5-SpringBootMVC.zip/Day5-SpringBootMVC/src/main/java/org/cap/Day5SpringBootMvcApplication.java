package org.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan("org.cap")
@SpringBootApplication(scanBasePackages= {"org.cap"})
public class Day5SpringBootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day5SpringBootMvcApplication.class, args);
	}
}
